<?php
session_start();
session_destroy();
header('Location: ingresar.php');
exit;
?>