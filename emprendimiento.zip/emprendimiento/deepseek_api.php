<?php
require_once 'config.php';

// Función para llamar a la API de DeepSeek
function consultarDeepSeek($mensaje, $historial = [], $contexto = []) {
    $apiKey = DEEPSEEK_API_KEY;
    $apiUrl = DEEPSEEK_API_URL;
    
    // Verificar que la clave API esté configurada
    if (empty($apiKey) || $apiKey === 'sk-4b39ef0e9cb9443db39712b84d5fa3fa') {
        error_log("Error: Clave API de DeepSeek no configurada");
        return "⚠️ Error de configuración: La clave API no está configurada. Por favor, contacta al administrador.";
    }
    
    // Construir el sistema de contexto agrícola
    $sistemaContexto = "Eres un asesor agrícola especializado en El Salvador. Proporciona información precisa y práctica basada en fuentes oficiales como CENTA, MAG, UES y PROCAFE. Sé claro, conciso y enfocado en soluciones aplicables para pequeños y medianos agricultores.";
    
    // Añadir contexto específico si está disponible
    if (!empty($contexto['cultivo'])) {
        $sistemaContexto .= "\n\nContexto actual: Cultivo de " . $contexto['cultivo'];
    }
    if (!empty($contexto['suelo'])) {
        $sistemaContexto .= ", suelo " . $contexto['suelo'];
    }
    if (!empty($contexto['etapa'])) {
        $sistemaContexto .= ", etapa de " . $contexto['etapa'];
    }
    
    // Preparar mensajes para la API
    $mensajes = [
        [
            'role' => 'system',
            'content' => $sistemaContexto
        ]
    ];
    
    // Añadir historial de conversación
    foreach ($historial as $mensajeHistorial) {
        if (is_array($mensajeHistorial) && isset($mensajeHistorial['role']) && isset($mensajeHistorial['content'])) {
            $mensajes[] = $mensajeHistorial;
        }
    }
    
    // Añadir el mensaje actual del usuario
    $mensajes[] = [
        'role' => 'user',
        'content' => $mensaje
    ];
    
    // Datos para la API
    $datos = [
        'model' => 'deepseek-chat',
        'messages' => $mensajes,
        'temperature' => 0.7,
        'max_tokens' => 2000,
        'stream' => false
    ];
    
    // Configurar cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($datos));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    $respuesta = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    // Log para debugging
    error_log("DeepSeek API Response - Code: $httpCode, Error: $curlError");
    
    if ($httpCode === 200) {
        $datosRespuesta = json_decode($respuesta, true);
        if (isset($datosRespuesta['choices'][0]['message']['content'])) {
            return $datosRespuesta['choices'][0]['message']['content'];
        } else {
            error_log("Error en respuesta API: " . $respuesta);
            return "❌ Error: No se pudo procesar la respuesta de la IA.";
        }
    } else {
        error_log("Error API DeepSeek: Código $httpCode - $respuesta - Error cURL: $curlError");
        
        // Mensajes de error más específicos
        if ($httpCode === 401) {
            return "🔐 Error de autenticación: La clave API no es válida o ha expirado.";
        } elseif ($httpCode === 429) {
            return "⏰ Límite de solicitudes excedido. Por favor, espera unos minutos.";
        } elseif ($httpCode === 503) {
            return "🛠️ Servicio temporalmente no disponible. Intenta nuevamente en unos momentos.";
        } else {
            return "❌ Error de conexión con el servicio de IA (Código: $httpCode). Por favor, intenta nuevamente.";
        }
    }
}

// Manejar solicitudes AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'consultar_ia') {
    header('Content-Type: application/json');
    
    $mensaje = trim($_POST['mensaje'] ?? '');
    $historial = json_decode($_POST['historial'] ?? '[]', true) ?? [];
    $contexto = json_decode($_POST['contexto'] ?? '[]', true) ?? [];
    
    if (empty($mensaje)) {
        echo json_encode(['success' => false, 'error' => 'El mensaje está vacío']);
        exit;
    }
    
    $respuesta = consultarDeepSeek($mensaje, $historial, $contexto);
    
    if (!empty($respuesta)) {
        echo json_encode([
            'success' => true,
            'respuesta' => $respuesta,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'No se recibió respuesta del servicio de IA'
        ]);
    }
    exit;
}
// Manejar solicitudes AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'consultar_ia') {
    header('Content-Type: application/json');
    
    try {
        $mensaje = trim($_POST['mensaje'] ?? '');
        $historial = json_decode($_POST['historial'] ?? '[]', true) ?? [];
        $contexto = json_decode($_POST['contexto'] ?? '[]', true) ?? [];
        
        if (empty($mensaje)) {
            throw new Exception('El mensaje está vacío');
        }
        
        $respuesta = consultarDeepSeek($mensaje, $historial, $contexto);
        
        if ($respuesta !== false) {
            echo json_encode([
                'success' => true,
                'respuesta' => $respuesta,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        } else {
            throw new Exception('Error al conectar con el servicio de IA');
        }
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}
?>