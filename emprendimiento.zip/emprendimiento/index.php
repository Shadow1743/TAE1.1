<?php
require_once 'config.php';
require_once 'deepseek_api.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asesor Agrícola - El Salvador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <img src="Logo.jpeg" alt="Logo" class="navbar-logo">
            <a class="navbar-brand fw-bold" href="#">TecnoAgroEcologi</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="inicio.html"><i class="fas fa-home me-1"></i> Inicio</a></li>
                    <li class="nav-item"><a class="nav-link active fw-bold" href="#"><i class="fas fa-robot me-1"></i> Asesor IA</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i> Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Chat Container -->
    <div class="container my-4">
        <div class="chat-container card-effect">
            <div class="chat-header">
                <button class="clear-chat-btn" id="clearChatBtn" title="Limpiar conversación">
                    <i class="fas fa-trash-alt"></i>
                </button>
                <button class="search-chat-btn" id="searchChatBtn" title="Buscar en fuentes agrícolas">
                    <i class="fas fa-search"></i>
                </button>
                <h3><i class="fas fa-seedling me-2"></i>Asesor Agrícola de El Salvador</h3>
                <p class="mb-0">Conectado a DeepSeek AI - Respuestas especializadas</p>
                <div class="api-status" id="apiStatus">
                    <span class="status-indicator status-connected" id="statusIndicator"></span>
                    <span id="statusText">AgroAsistente SV - Conectado</span>
                </div>
                <div class="chat-header-badge">
                    <i class="fas fa-brain me-1"></i> DeepSeek AI + Fuentes locales
                </div>
            </div>
            
            <!-- Selector de Contexto -->
            <div class="context-selector card-effect">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="cropType" class="form-label"><i class="fas fa-leaf me-2"></i>Cultivo</label>
                        <select class="form-select" id="cropType">
                            <option value="" selected>Seleccionar...</option>
                            <option value="maiz">Maíz</option>
                            <option value="frijol">Frijol</option>
                            <option value="cafe">Café</option>
                            <option value="hortalizas">Hortalizas</option>
                            <option value="frutales">Frutales</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="soilType" class="form-label"><i class="fas fa-mountain me-2"></i>Tipo de Suelo</label>
                        <select class="form-select" id="soilType">
                            <option value="" selected>Seleccionar...</option>
                            <option value="arcilloso">Arcilloso</option>
                            <option value="arenoso">Arenoso</option>
                            <option value="limoso">Limoso</option>
                            <option value="franco">Franco</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="growthStage" class="form-label"><i class="fas fa-seedling me-2"></i>Etapa</label>
                        <select class="form-select" id="growthStage">
                            <option value="" selected>Seleccionar...</option>
                            <option value="siembra">Siembra</option>
                            <option value="crecimiento">Crecimiento</option>
                            <option value="floracion">Floración</option>
                            <option value="cosecha">Cosecha</option>
                        </select>
                    </div>
                </div>
                <button id="fetchWeatherBtn" class="btn btn-outline-success mt-3">
                    <i class="fas fa-cloud-sun me-1"></i>Obtener clima local
                </button>
            </div>
            
            <!-- Search Container -->
            <div class="search-container card-effect" id="searchContainer" style="display: none;">
                <div class="input-group">
                    <input type="text" class="form-control" id="searchInput" placeholder="Buscar en fuentes agrícolas..." aria-label="Buscar">
                    <button class="btn btn-success" type="button" id="performSearchBtn">
                        <i class="fas fa-search me-1"></i> Buscar
                    </button>
                </div>
                <div class="search-results mt-3" id="searchResults"></div>
            </div>
            
            <!-- Advanced Options -->
            <div class="advanced-options" id="advancedOptions">
                <h6><i class="fas fa-cogs me-2"></i>Opciones avanzadas</h6>
                <div class="response-quality">
                    <span>Calidad de respuesta:</span>
                    <button class="quality-btn" data-quality="concise">Breve</button>
                    <button class="quality-btn active" data-quality="standard">Estándar</button>
                    <button class="quality-btn" data-quality="detailed">Detallada</button>
                </div>
                <div class="report-options">
                    <span>Generar reporte:</span>
                    <button class="report-btn" data-report="summary">
                        <i class="fas fa-file-alt me-1"></i> Resumen
                    </button>
                    <button class="report-btn" data-report="technical">
                        <i class="fas fa-file-code me-1"></i> Técnico
                    </button>
                    <button class="report-btn" data-report="action">
                        <i class="fas fa-tasks me-1"></i> Plan de acción
                    </button>
                </div>
            </div>
            
            <!-- Chat Body -->
            <div class="chat-body" id="chatBody">
                <div class="message ai-message">
                    <div class="message-header">
                        <div class="ai-icon">
                            <i class="fas fa-robot"></i>
                        </div>
                        <div>Asistente Agrícola SV</div>
                    </div>
                    <div class="message-content">
                        <p>¡Hola! Soy tu asesor agrícola especializado en El Salvador, ahora potenciado con <strong>DeepSeek AI</strong>.</p>
                        <ul>
                            <li><strong>Respuestas en tiempo real</strong> con inteligencia artificial avanzada</li>
                            <li>Información contextualizada para <strong>El Salvador</strong></li>
                            <li>Capacidad de entender <strong>conversaciones complejas</strong></li>
                            <li>Integración con <strong>fuentes locales verificadas</strong></li>
                        </ul>
                        <p class="mt-2">Selecciona tu contexto agrícola o simplemente haz tu pregunta.</p>
                        <div class="salvador-badge">
                            <i class="fas fa-bolt me-1"></i> Conectado a DeepSeek AI
                        </div>
                    </div>
                </div>
                
                <!-- Preguntas Sugeridas -->
                <div class="suggestions mb-4">
                    <button class="suggestion-btn" data-question="¿Cuál es la mejor época para sembrar maíz en El Salvador considerando el cambio climático?">
                        <i class="fas fa-calendar-day"></i> Época de siembra
                    </button>
                    <button class="suggestion-btn" data-question="¿Qué plagas comunes afectan los cultivos en El Salvador y cómo controlarlas de manera orgánica?">
                        <i class="fas fa-bug"></i> Control orgánico
                    </button>
                    <button class="suggestion-btn" data-question="¿Qué técnicas de riego son más eficientes para pequeños agricultores en zonas secas?">
                        <i class="fas fa-tint"></i> Riego eficiente
                    </button>
                    <button class="suggestion-btn" data-question="¿Cómo preparar abonos orgánicos caseros con materiales locales?">
                        <i class="fas fa-recycle"></i> Abonos orgánicos
                    </button>
                </div>
            </div>

            <!-- Typing Indicator -->
            <div class="typing-indicator" id="typingIndicator">
                <i class="fas fa-robot me-2"></i>DeepSeek AI está procesando tu consulta...
            </div>
            
            <!-- Chat Input con opción de fuentes -->
            <div class="chat-input">
                <div class="source-toggle">
                    <div class="toggle-text">
                        <i class="fas fa-brain me-2"></i>Modo IA Avanzado
                    </div>
                    <label class="toggle-switch">
                        <input type="checkbox" id="includeSourcesToggle" checked>
                        <span class="slider"></span>
                    </label>
                </div>
                
                <div class="input-group mt-3">
                    <input type="text" class="form-control" id="userInput" placeholder="Escribe tu consulta agrícola..." aria-label="Mensaje">
                    <button class="btn btn-success" type="button" id="sendButton">
                        <i class="fas fa-paper-plane me-1"></i> Enviar
                    </button>
                </div>
                <small class="text-muted d-block mt-2">Presiona Enter para enviar - DeepSeek AI</small>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="app.js"></script>
</body>
</html>