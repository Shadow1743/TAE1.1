<?php
define('DEEPSEEK_API_KEY', 'sk-28b8897afea149ba855c22eac7e59660');
define('DEEPSEEK_API_URL', 'https://api.deepseek.com/v1/chat/completions');

$datos = [
    'model' => 'deepseek-chat',
    'messages' => [
        ['role' => 'user', 'content' => 'Hola, responde con "OK" si funciona']
    ],
    'max_tokens' => 50
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, DEEPSEEK_API_URL);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($datos));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . DEEPSEEK_API_KEY
]);

$respuesta = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "Código HTTP: $httpCode<br>";
echo "Respuesta: " . htmlspecialchars($respuesta);
?>