<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ingresar.php');
    exit;
}

$usuario = $_SESSION['usuario'] ?? [];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asesor Agrícola - El Salvador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .search-chat-btn {
            background: none;
            border: none;
            color: #fff;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: background-color 0.3s;
        }

        .search-chat-btn:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .search-container {
            margin-top: 1rem;
            padding: 1rem;
        }

        .search-result-item {
            margin-bottom: 1rem;
            padding: 1rem;
            border-left: 4px solid #28a745;
        }

        .search-result-item h5 {
            color: #2e7d32;
            margin-bottom: 0.5rem;
        }

        .advanced-options {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            border: 1px solid #e9ecef;
        }

        .response-quality {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }

        .quality-btn {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            border: 1px solid #dee2e6;
            background: white;
            cursor: pointer;
            transition: all 0.3s;
        }

        .quality-btn.active {
            background: #28a745;
            color: white;
            border-color: #28a745;
        }

        .report-options {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .report-btn {
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 8px 15px;
            border-radius: 5px;
            background: white;
            border: 1px solid #dee2e6;
            cursor: pointer;
            transition: all 0.3s;
        }

        .report-btn:hover {
            background: #f8f9fa;
            border-color: #28a745;
        }

        .knowledge-graph {
            margin-top: 15px;
            padding: 10px;
            background: #e8f5e9;
            border-radius: 8px;
            border-left: 4px solid #2e7d32;
        }

        .graph-nodes {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }

        .graph-node {
            padding: 5px 10px;
            background: white;
            border-radius: 20px;
            border: 1px solid #c8e6c9;
            font-size: 0.85rem;
        }

        .node-main {
            background: #4caf50;
            color: white;
        }

        .typing-indicator {
            display: none;
            padding: 1rem;
            color: #666;
            font-style: italic;
            background: #f8f9fa;
            border-radius: 10px;
            margin: 0.5rem 1rem;
        }

        .source-toggle {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0;
        }

        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }

        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 24px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: #28a745;
        }

        input:checked + .slider:before {
            transform: translateX(26px);
        }

        .salvador-badge {
            background: linear-gradient(135deg, #2e7d32, #4caf50);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            display: inline-block;
            margin-top: 0.5rem;
        }

        .api-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            margin-top: 0.5rem;
        }

        .status-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
        }

        .status-connected {
            background-color: #28a745;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }

        .chat-header-badge {
            background: rgba(255,255,255,0.2);
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.75rem;
            display: inline-block;
            margin-top: 0.5rem;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <img src="Logo.jpeg" alt="Logo" class="navbar-logo">
            <a class="navbar-brand fw-bold" href="#">TecnoAgroEcologi</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="inicio.html"><i class="fas fa-home me-1"></i> Inicio</a></li>
                    <li class="nav-item"><a class="nav-link active fw-bold" href="#"><i class="fas fa-robot me-1"></i> Asesor IA</a></li>
                    <li class="nav-item"><a class="nav-link" href="#" id="logoutBtn"><i class="fas fa-sign-out-alt me-1"></i> Cerrar Sesión</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Chat Container -->
    <div class="container my-4">
        <div class="chat-container card-effect">
            <div class="chat-header">
                <button class="clear-chat-btn" id="clearChatBtn" title="Limpiar conversación">
                    <i class="fas fa-trash-alt"></i>
                </button>
                <button class="search-chat-btn" id="searchChatBtn" title="Buscar en fuentes agrícolas">
                    <i class="fas fa-search"></i>
                </button>
                <h3><i class="fas fa-seedling me-2"></i>Asesor Agrícola de El Salvador</h3>
                <p class="mb-0">Respuestas especializadas en agricultura</p>
                <div class="api-status">
                    <span class="status-indicator status-connected"></span>
                    AgroAsistente SV - Conectado
                </div>
                <div class="chat-header-badge">
                    <i class="fas fa-map-marker-alt me-1"></i> Fuentes locales verificadas
                </div>
            </div>
            
            <!-- Selector de Contexto -->
            <div class="context-selector card-effect">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="cropType" class="form-label"><i class="fas fa-leaf me-2"></i>Cultivo</label>
                        <select class="form-select" id="cropType">
                            <option value="" selected>Seleccionar...</option>
                            <option value="maiz">Maíz</option>
                            <option value="frijol">Frijol</option>
                            <option value="cafe">Café</option>
                            <option value="hortalizas">Hortalizas</option>
                            <option value="frutales">Frutales</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="soilType" class="form-label"><i class="fas fa-mountain me-2"></i>Tipo de Suelo</label>
                        <select class="form-select" id="soilType">
                            <option value="" selected>Seleccionar...</option>
                            <option value="arcilloso">Arcilloso</option>
                            <option value="arenoso">Arenoso</option>
                            <option value="limoso">Limoso</option>
                            <option value="franco">Franco</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="growthStage" class="form-label"><i class="fas fa-seedling me-2"></i>Etapa</label>
                        <select class="form-select" id="growthStage">
                            <option value="" selected>Seleccionar...</option>
                            <option value="siembra">Siembra</option>
                            <option value="crecimiento">Crecimiento</option>
                            <option value="floracion">Floración</option>
                            <option value="cosecha">Cosecha</option>
                        </select>
                    </div>
                </div>
                <button id="fetchWeatherBtn" class="btn btn-outline-success mt-3">
                    <i class="fas fa-cloud-sun me-1"></i>Obtener clima local
                </button>
            </div>
            
            <!-- Search Container -->
            <div class="search-container card-effect" id="searchContainer" style="display: none;">
                <div class="input-group">
                    <input type="text" class="form-control" id="searchInput" placeholder="Buscar en fuentes agrícolas..." aria-label="Buscar">
                    <button class="btn btn-success" type="button" id="performSearchBtn">
                        <i class="fas fa-search me-1"></i> Buscar
                    </button>
                </div>
                <div class="search-results mt-3" id="searchResults"></div>
            </div>
            
            <!-- Advanced Options -->
            <div class="advanced-options" id="advancedOptions">
                <h6><i class="fas fa-cogs me-2"></i>Opciones avanzadas</h6>
                <div class="response-quality">
                    <span>Calidad de respuesta:</span>
                    <button class="quality-btn" data-quality="concise">Breve</button>
                    <button class="quality-btn active" data-quality="standard">Estándar</button>
                    <button class="quality-btn" data-quality="detailed">Detallada</button>
                </div>
                <div class="report-options">
                    <span>Generar reporte:</span>
                    <button class="report-btn" data-report="summary">
                        <i class="fas fa-file-alt me-1"></i> Resumen
                    </button>
                    <button class="report-btn" data-report="technical">
                        <i class="fas fa-file-code me-1"></i> Técnico
                    </button>
                    <button class="report-btn" data-report="action">
                        <i class="fas fa-tasks me-1"></i> Plan de acción
                    </button>
                </div>
            </div>
            
            <!-- Chat Body -->
            <div class="chat-body" id="chatBody">
                <div class="message ai-message">
                    <div class="message-header">
                        <div class="ai-icon">
                            <i class="fas fa-robot"></i>
                        </div>
                        <div>Asistente Agrícola SV</div>
                    </div>
                    <div class="message-content">
                        <p>¡Hola! Soy tu asesor agrícola especializado en El Salvador. He sido mejorado con nuevas capacidades:</p>
                        <ul>
                            <li>Puedes buscar información específica en nuestras fuentes</li>
                            <li>Mis respuestas son más contextuales y detalladas</li>
                            <li>Puedo generar diferentes tipos de reportes</li>
                            <li>Ahora entiendo mejor el contexto de tus preguntas</li>
                        </ul>
                        <p class="mt-2">Selecciona tu contexto o simplemente haz tu pregunta.</p>
                        <div class="salvador-badge">Fuentes locales verificadas</div>
                    </div>
                </div>
                
                <!-- Preguntas Sugeridas -->
                <div class="suggestions mb-4">
                    <button class="suggestion-btn" data-question="¿Cuál es la mejor época para sembrar maíz en El Salvador?">
                        <i class="fas fa-calendar-day"></i> Época de siembra
                    </button>
                    <button class="suggestion-btn" data-question="¿Qué plagas comunes afectan los cultivos en El Salvador y cómo controlarlas?">
                        <i class="fas fa-bug"></i> Plagas comunes
                    </button>
                    <button class="suggestion-btn" data-question="¿Qué técnicas de riego son más eficientes para pequeños agricultores?">
                        <i class="fas fa-tint"></i> Técnicas de riego
                    </button>
                    <button class="suggestion-btn" data-question="¿Cómo preparar abonos orgánicos caseros?">
                        <i class="fas fa-recycle"></i> Abonos orgánicos
                    </button>
                </div>
            </div>

            <!-- Typing Indicator -->
            <div class="typing-indicator" id="typingIndicator">
                <i class="fas fa-robot me-2"></i>El asistente está escribiendo...
            </div>
            
            <!-- Chat Input con opción de fuentes -->
            <div class="chat-input">
                <div class="source-toggle">
                    <div class="toggle-text">
                        <i class="fas fa-book me-2"></i>Incluir fuentes en respuestas
                    </div>
                    <label class="toggle-switch">
                        <input type="checkbox" id="includeSourcesToggle" checked>
                        <span class="slider"></span>
                    </label>
                </div>
                
                <div class="input-group mt-3">
                    <input type="text" class="form-control" id="userInput" placeholder="Escribe tu consulta agrícola..." aria-label="Mensaje">
                    <button class="btn btn-success" type="button" id="sendButton">
                        <i class="fas fa-paper-plane me-1"></i> Enviar
                    </button>
                </div>
                <small class="text-muted d-block mt-2">Presiona Enter para enviar</small>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Variables globales
        let includeSources = true;
        let responseQuality = 'standard';
        let currentContext = {
            crop: '',
            soil: '',
            stage: '',
            weather: null
        };
        
        let conversationHistory = [];
        let isProcessing = false;

        // Base de datos de documentos agrícolas
        const agriculturalDocuments = [
            {
                title: "Manual de Cultivo de Maíz - CENTA",
                content: "El cultivo de maíz requiere suelos bien drenados y pH entre 6 y 7. La siembra se realiza en mayo-junio con una densidad de 60,000 plantas por hectárea. Se recomienda fertilización basada en análisis de suelo.",
                source: "CENTA",
                url: "https://www.centa.gob.sv/publicaciones/maiz",
                keywords: ["maiz", "siembra", "fertilización", "suelo"]
            },
            {
                title: "Guía de Plagas del Frijol - CENTA",
                content: "Las principales plagas del frijol son el picudo y la mosca blanca. Se recomienda el control integrado con trampas amarillas y beauveria bassiana.",
                source: "CENTA",
                url: "https://www.centa.gob.sv/publicaciones/frijol-plagas",
                keywords: ["frijol", "plagas", "picudo", "mosca blanca"]
            },
            {
                title: "Técnicas de Riego por Goteo - UES",
                content: "El riego por goteo permite ahorrar hasta un 40% de agua. Se recomienda para hortalizas y frutales. La frecuencia de riego depende del tipo de suelo y clima.",
                source: "UES",
                url: "https://www.ues.edu.sv/investigacion/riego-goteo",
                keywords: ["riego", "goteo", "agua", "hortalizas"]
            }
        ];

        // Inicializar la aplicación
        document.addEventListener('DOMContentLoaded', function() {
            initApp();
        });

        function initApp() {
            // Inicializar elementos del DOM
            const chatBody = document.getElementById('chatBody');
            const userInput = document.getElementById('userInput');
            const sendButton = document.getElementById('sendButton');
            const cropTypeSelect = document.getElementById('cropType');
            const soilTypeSelect = document.getElementById('soilType');
            const growthStageSelect = document.getElementById('growthStage');
            const fetchWeatherBtn = document.getElementById('fetchWeatherBtn');
            const clearChatBtn = document.getElementById('clearChatBtn');
            const includeSourcesToggle = document.getElementById('includeSourcesToggle');
            const typingIndicator = document.getElementById('typingIndicator');
            
            // Elementos de búsqueda
            const searchChatBtn = document.getElementById('searchChatBtn');
            const searchContainer = document.getElementById('searchContainer');
            const searchInput = document.getElementById('searchInput');
            const performSearchBtn = document.getElementById('performSearchBtn');
            const searchResults = document.getElementById('searchResults');
            
            // Elementos de opciones avanzadas
            const qualityButtons = document.querySelectorAll('.quality-btn');
            const reportButtons = document.querySelectorAll('.report-btn');

            // Event Listeners básicos
            sendButton.addEventListener('click', sendMessage);
            userInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter' && !isProcessing) {
                    sendMessage();
                }
            });

            clearChatBtn.addEventListener('click', clearChat);
            
            includeSourcesToggle.addEventListener('change', function() {
                includeSources = this.checked;
                addMessage('system', `Fuentes en respuestas: ${this.checked ? 'Activadas' : 'Desactivadas'}`);
            });

            // Event listeners para preguntas sugeridas
            document.querySelectorAll('.suggestion-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const question = this.getAttribute('data-question');
                    userInput.value = question;
                    sendMessage();
                });
            });

            // Event listeners para selectores de contexto
            [cropTypeSelect, soilTypeSelect, growthStageSelect].forEach(select => {
                select.addEventListener('change', updateContext);
            });

            // Event listeners para búsqueda
            searchChatBtn.addEventListener('click', toggleSearchContainer);
            performSearchBtn.addEventListener('click', performSearch);
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') performSearch();
            });

            // Event listeners para opciones avanzadas
            qualityButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    qualityButtons.forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    responseQuality = this.dataset.quality;
                    addMessage('system', `Calidad de respuesta: ${getQualityLabel(responseQuality)}`);
                });
            });

            reportButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    generateReport(this.dataset.report);
                });
            });

            // Clima local
            fetchWeatherBtn.addEventListener('click', fetchLocalWeather);
        }

        // Función principal para enviar mensajes
        async function sendMessage() {
            const userInput = document.getElementById('userInput');
            const message = userInput.value.trim();
            
            if (!message || isProcessing) return;

            isProcessing = true;
            document.getElementById('sendButton').disabled = true;
            userInput.disabled = true;

            try {
                // Añadir mensaje del usuario
                addMessage('user', message);
                userInput.value = '';

                // Mostrar indicador de escritura
                showTypingIndicator();

                // Obtener respuesta de la IA
                const response = await getAIResponse(message);
                
                // Añadir respuesta al chat
                addMessage('ai', response);

            } catch (error) {
                console.error('Error:', error);
                addMessage('ai', 'Lo siento, hubo un error al procesar tu solicitud. Por favor, intenta nuevamente.');
            } finally {
                hideTypingIndicator();
                isProcessing = false;
                document.getElementById('sendButton').disabled = false;
                userInput.disabled = false;
                userInput.focus();
            }
        }

        // Obtener respuesta de la IA
        async function getAIResponse(userMessage) {
            // Simulación de API - En producción reemplazar con llamada real a DeepSeek
            return new Promise((resolve) => {
                setTimeout(() => {
                    const response = generateAgriculturalResponse(userMessage);
                    resolve(response);
                }, 2000);
            });
        }

        // Generar respuesta agrícola contextual
        function generateAgriculturalResponse(userMessage) {
            const lowerMessage = userMessage.toLowerCase();
            const context = getCurrentContext();
            let contextInfo = '';
            
            if (context.crop) {
                contextInfo += ` para ${getCropName(context.crop)}`;
            }
            if (context.soil) {
                contextInfo += ` en suelo ${context.soil}`;
            }
            if (context.stage) {
                contextInfo += ` en etapa de ${context.stage}`;
            }

            // Respuestas basadas en palabras clave y contexto
            if (lowerMessage.includes('maíz') || lowerMessage.includes('maiz')) {
                return `Para el cultivo de maíz${contextInfo} en El Salvador, el CENTA recomienda:

🌱 **Épocas de siembra:**
   - Primera: Mayo-junio (inicio de lluvias)
   - Postrera: Agosto-septiembre

📊 **Manejo técnico:**
   - Densidad: 60,000 plantas/hectárea
   - Fertilización: 120-150-60 kg/ha (N-P-K)
   - Profundidad: 3-5 cm

🐛 **Principales plagas:**
   - Gusano cogollero (Spodoptera frugiperda)
   - Pulgón amarillo (Melanaphis sacchari)
   - Gallina ciega (Phyllophaga spp.)

💧 **Requerimientos hídricos:** 500-800 mm/ciclo

📈 **Rendimiento esperado:** 60-80 qq/ha con buen manejo

*Fuente: CENTA - Manual técnico del cultivo de maíz 2024*`;

            } else if (lowerMessage.includes('frijol')) {
                return `Recomendaciones para el cultivo de frijol${contextInfo}:

🌱 **Época de siembra:**
   - Postrera: Agosto-septiembre (principal)
   - Apante: Diciembre-enero (con riego)

📊 **Manejo técnico:**
   - Densidad: 120,000 plantas/hectárea
   - Profundidad: 3-4 cm
   - Marco: 50 cm entre surcos

🐛 **Plagas principales:**
   - Picudo del frijol (Zabrotes subfasciatus)
   - Mosca blanca (Bemisia tabaci)
   - Trips (Frankliniella spp.)

🌿 **Enfermedades comunes:**
   - Mustia hilachosa
   - Mancha angular
   - Antracnosis

💧 **Riego:** 400-600 mm por ciclo

*Fuente: CENTA - Guía técnica del cultivo de frijol*`;

            } else if (lowerMessage.includes('café') || lowerMessage.includes('cafe')) {
                return `Para el cultivo de café${contextInfo} en El Salvador:

🌱 **Época de siembra:**
   - Junio-julio con inicio de lluvias
   - Requiere sombra adecuada (40-60%)

📊 **Manejo técnico:**
   - Densidad: 2,500-3,500 plantas/ha
   - Podas de formación y producción
   - Fertilización balanceada

🍂 **Enfermedades principales:**
   - Roya del café (Hemileia vastatrix)
   - Ojo de gallo (Mycena citricolor)
   - Broca (Hypothenemus hampei)

💧 **Requerimientos:** 1,200-1,800 mm anuales

🌿 **Variedades recomendadas:**
   - Pacamara
   - Bourbon
   - Catimor

*Fuente: PROCAFE - Buenas prácticas agrícolas*`;

            } else if (lowerMessage.includes('siembra') || lowerMessage.includes('época')) {
                return `**Calendario de siembra - El Salvador** (CENTA 2024):

🌽 **Maíz:**
   - Primera: Mayo-junio
   - Postrera: Agosto-septiembre

🫘 **Frijol:**
   - Postrera: Agosto-septiembre (principal)
   - Apante: Diciembre-enero

☕ **Café:**
   - Junio-julio (inicio de lluvias)

🥬 **Hortalizas:**
   - Todo el año con riego adecuado

🌿 **Recomendaciones generales:**
   - Realizar análisis de suelo previo
   - Usar semilla certificada
   - Considerar pronóstico climático
   - Preparar el suelo adecuadamente

*Fuente: CENTA - Calendario de siembra 2024*`;

            } else if (lowerMessage.includes('plaga') || lowerMessage.includes('insecto')) {
                return `**Manejo Integrado de Plagas (MIP)** - Recomendaciones MAG:

🐛 **Plagas principales en El Salvador:**

**Maíz:**
- Gusano cogollero: Control con Bacillus thuringiensis
- Pulgón amarillo: Insecticidas sistémicos

**Frijol:**
- Picudo: Trampas y control biológico
- Mosca blanca: Aceites vegetales y jabones

**Café:**
- Broca: Trampas alcohol-éter, control cultural
- Minador de la hoja: Podas sanitarias

🛡️ **Estrategias de MIP:**
1. Monitoreo constante
2. Control biológico (avispas, hongos benéficos)
3. Control cultural (rotación, podas)
4. Control químico racional

🌿 **Productos recomendados:**
- Beauveria bassiana (hongos)
- Bacillus thuringiensis (bacterias)
- Nim (Azadirachta indica)

*Fuente: MAG - Manual de MIP 2024*`;

            } else if (lowerMessage.includes('riego') || lowerMessage.includes('agua')) {
                return `**Sistemas de riego eficientes** - Recomendaciones UES:

💧 **Riego por goteo:**
   - Ahorro: 40-60% de agua
   - Ideal para: Hortalizas, frutales
   - Ventajas: Alta eficiencia, menor evaporación

💧 **Aspersión:**
   - Ahorro: 30-50% de agua
   - Ideal para: Cultivos extensivos
   - Ventajas: Cobertura uniforme

💧 **Microaspersión:**
   - Ideal para: Frutales, viveros
   - Ventajas: Mayor cobertura que goteo

📊 **Recomendaciones para El Salvador:**
- Programar riegos según necesidades del cultivo
- Considerar tipo de suelo y clima
- Realizar riegos en horas tempranas o tardías
- Implementar sensores de humedad

💡 **Innovaciones:**
- Riego por goteo subterráneo
- Sistemas automatizados
- Uso de aguas residuales tratadas

*Fuente: UES - Departamento de Ingeniería Agrícola*`;

            } else {
                return `¡Hola! Soy tu asesor agrícola especializado en El Salvador ${contextInfo}. 

Puedo ayudarte con información sobre:

🌱 **Cultivos:** Maíz, frijol, café, hortalizas, frutales
🐛 **Manejo de plagas y enfermedades**
💧 **Sistemas de riego y manejo del agua**
🌿 **Fertilización y manejo de suelos**
📅 **Calendarios de siembra**
📊 **Análisis de costos y rentabilidad**

Para obtener recomendaciones más precisas, selecciona tu cultivo, tipo de suelo y etapa de crecimiento en los selectores superiores.

*Toda la información proviene de fuentes oficiales: CENTA, MAG, UES, PROCAFE*`;
            }
        }

        // Funciones auxiliares
        function getCurrentContext() {
            const cropTypeSelect = document.getElementById('cropType');
            const soilTypeSelect = document.getElementById('soilType');
            const growthStageSelect = document.getElementById('growthStage');
            
            return {
                crop: cropTypeSelect.value,
                soil: soilTypeSelect.value,
                stage: growthStageSelect.value,
                weather: currentContext.weather
            };
        }

        function getCropName(cropValue) {
            const crops = {
                'maiz': 'Maíz',
                'frijol': 'Frijol',
                'cafe': 'Café',
                'hortalizas': 'Hortalizas',
                'frutales': 'Frutales'
            };
            return crops[cropValue] || cropValue;
        }

        function getQualityLabel(quality) {
            const labels = {
                'concise': 'Breve',
                'standard': 'Estándar',
                'detailed': 'Detallada'
            };
            return labels[quality] || 'Estándar';
        }

        // Funciones de UI
        function addMessage(role, content) {
            const chatBody = document.getElementById('chatBody');
            
            hideTypingIndicator();
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${role}-message fade-in`;
            
            const icon = role === 'user' 
                ? `<div class="user-icon"><i class="fas fa-user"></i></div>` 
                : `<div class="ai-icon"><i class="fas fa-robot"></i></div>`;
            
            const title = role === 'user' ? 'Tú' : 'Asistente Agrícola SV';
            
            messageDiv.innerHTML = `
                <div class="message-header">
                    ${icon}
                    <div>${title}</div>
                </div>
                <div class="message-content">${content.replace(/\n/g, '<br>')}</div>
            `;
            
            chatBody.appendChild(messageDiv);
            scrollToBottom();
            
            // Remover sugerencias después del primer mensaje
            if (role === 'user') {
                const suggestions = document.querySelector('.suggestions');
                if (suggestions) {
                    suggestions.style.display = 'none';
                }
            }
        }

        function showTypingIndicator() {
            const typingIndicator = document.getElementById('typingIndicator');
            typingIndicator.style.display = 'block';
            scrollToBottom();
        }

        function hideTypingIndicator() {
            const typingIndicator = document.getElementById('typingIndicator');
            typingIndicator.style.display = 'none';
        }

        function scrollToBottom() {
            const chatBody = document.getElementById('chatBody');
            chatBody.scrollTop = chatBody.scrollHeight;
        }

        // Funciones de las características adicionales
        function toggleSearchContainer() {
            const searchContainer = document.getElementById('searchContainer');
            const searchInput = document.getElementById('searchInput');
            
            searchContainer.style.display = searchContainer.style.display === 'none' ? 'block' : 'none';
            if (searchContainer.style.display === 'block') {
                searchInput.focus();
            }
        }

        function performSearch() {
            const searchInput = document.getElementById('searchInput');
            const searchResults = document.getElementById('searchResults');
            const query = searchInput.value.trim().toLowerCase();
            
            if (!query) return;

            const results = agriculturalDocuments.filter(doc => 
                doc.keywords.some(keyword => keyword.includes(query)) ||
                doc.title.toLowerCase().includes(query) ||
                doc.content.toLowerCase().includes(query)
            );

            displaySearchResults(results, query);
        }

        function displaySearchResults(results, query) {
            const searchResults = document.getElementById('searchResults');
            searchResults.innerHTML = '';

            if (results.length === 0) {
                searchResults.innerHTML = `<p class="text-muted">No se encontraron resultados para "${query}".</p>`;
                return;
            }

            results.forEach(doc => {
                const docElement = document.createElement('div');
                docElement.className = 'search-result-item';
                docElement.innerHTML = `
                    <h5>${doc.title}</h5>
                    <p>${doc.content}</p>
                    <div class="text-end">
                        <span class="badge bg-success">${doc.source}</span>
                        <a href="${doc.url}" target="_blank" class="btn btn-sm btn-outline-success ms-2">Ver fuente</a>
                    </div>
                `;
                searchResults.appendChild(docElement);
            });
        }

        function updateContext() {
            const context = getCurrentContext();
            if (context.crop) {
                addMessage('system', `Contexto actualizado: ${getCropName(context.crop)}`);
            }
        }

        function fetchLocalWeather() {
            showTypingIndicator("Obteniendo información del clima...");
            
            setTimeout(() => {
                const weatherData = {
                    temp: 28,
                    rain: 2,
                    humidity: 75,
                    condition: 'Parcialmente nublado'
                };
                
                currentContext.weather = weatherData;
                
                hideTypingIndicator();
                addMessage('system', `🌤️ Clima actual: ${weatherData.temp}°C, ${weatherData.rain}mm de lluvia, ${weatherData.humidity}% humedad. ${weatherData.condition}.`);
            }, 1500);
        }

        function generateReport(type) {
            const context = getCurrentContext();
            if (!context.crop) {
                addMessage('assistant', 'Primero selecciona un cultivo para generar un reporte.');
                return;
            }
            
            showTypingIndicator("Generando reporte...");
            
            setTimeout(() => {
                const cropName = getCropName(context.crop);
                addMessage('ai', `Reporte ${type} para ${cropName} generado exitosamente. Esta función está en desarrollo.`);
                hideTypingIndicator();
            }, 2000);
        }

        function clearChat() {
            const chatBody = document.getElementById('chatBody');
            chatBody.innerHTML = `
                <div class="message ai-message">
                    <div class="message-header">
                        <div class="ai-icon">
                            <i class="fas fa-robot"></i>
                        </div>
                        <div>Asistente Agrícola SV</div>
                    </div>
                    <div class="message-content">
                        <p>¡Hola! Soy tu asesor agrícola especializado en El Salvador. He sido mejorado con nuevas capacidades:</p>
                        <ul>
                            <li>Puedes buscar información específica en nuestras fuentes</li>
                            <li>Mis respuestas son más contextuales y detalladas</li>
                            <li>Puedo generar diferentes tipos de reportes</li>
                            <li>Ahora entiendo mejor el contexto de tus preguntas</li>
                        </ul>
                        <p class="mt-2">Selecciona tu contexto o simplemente haz tu pregunta.</p>
                        <div class="salvador-badge">Fuentes locales verificadas</div>
                    </div>
                </div>
                <div class="suggestions mb-4">
                    <button class="suggestion-btn" data-question="¿Cuál es la mejor época para sembrar maíz en El Salvador?">
                        <i class="fas fa-calendar-day"></i> Época de siembra
                    </button>
                    <button class="suggestion-btn" data-question="¿Qué plagas comunes afectan los cultivos en El Salvador y cómo controlarlas?">
                        <i class="fas fa-bug"></i> Plagas comunes
                    </button>
                    <button class="suggestion-btn" data-question="¿Qué técnicas de riego son más eficientes para pequeños agricultores?">
                        <i class="fas fa-tint"></i> Técnicas de riego
                    </button>
                    <button class="suggestion-btn" data-question="¿Cómo preparar abonos orgánicos caseros?">
                        <i class="fas fa-recycle"></i> Abonos orgánicos
                    </button>
                </div>
            `;

            // Re-asignar event listeners
            document.querySelectorAll('.suggestion-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const question = this.getAttribute('data-question');
                    document.getElementById('userInput').value = question;
                    sendMessage();
                });
            });

            // Resetear selectores
            document.getElementById('cropType').value = '';
            document.getElementById('soilType').value = '';
            document.getElementById('growthStage').value = '';
            document.getElementById('includeSourcesToggle').checked = true;
            
            // Resetear calidad
            document.querySelectorAll('.quality-btn').forEach(btn => {
                btn.classList.remove('active');
                if (btn.dataset.quality === 'standard') {
                    btn.classList.add('active');
                }
            });
            
            includeSources = true;
            responseQuality = 'standard';
            currentContext = { crop: '', soil: '', stage: '', weather: null };
        }
    </script>
</body>
</html>