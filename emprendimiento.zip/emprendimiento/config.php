<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ingresar.php');
    exit;
}

// Configuración de la API de DeepSeek - REEMPLAZA CON TU CLAVE REAL
define('DEEPSEEK_API_KEY', 'sk-4b39ef0e9cb9443db39712b84d5fa3fa'); 
define('DEEPSEEK_API_URL', 'https://api.deepseek.com/v1/chat/completions');

// Configuración de la base de datos de documentos agrícolas
$agriculturalDocuments = [
    // ... (el resto igual)
];

?>