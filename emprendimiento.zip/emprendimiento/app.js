async function getAIResponse(userMessage) {
    const contexto = getCurrentContext();
    
    const datos = {
        action: 'consultar_ia',
        mensaje: userMessage,
        historial: JSON.stringify(conversationHistory),
        contexto: JSON.stringify(contexto)
    };

    try {
        const respuesta = await fetch('deepseek_api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams(datos)
        });

        // Verificar si la respuesta es OK (status 200-299)
        if (!respuesta.ok) {
            throw new Error(`Error HTTP: ${respuesta.status}`);
        }

        const resultado = await respuesta.json();

        if (resultado.success) {
            // Actualizar historial de conversación
            conversationHistory.push(
                { role: 'user', content: userMessage },
                { role: 'assistant', content: resultado.respuesta }
            );
            
            // Mantener solo los últimos 10 mensajes para no exceder límites
            if (conversationHistory.length > 10) {
                conversationHistory = conversationHistory.slice(-10);
            }
            
            updateStatus('DeepSeek AI - Conectado', 'connected');
            return resultado.respuesta;
        } else {
            throw new Error(resultado.error || 'Error desconocido en la API');
        }
    } catch (error) {
        console.error('Error en getAIResponse:', error);
        throw new Error('No se pudo conectar con el servidor. Verifica tu conexión a internet.');
    }
}